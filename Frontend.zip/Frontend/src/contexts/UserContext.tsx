import React, { createContext, useContext, useState, useEffect } from "react";
import { api } from "../api/client";

export interface SystemUser {
  id: string;
  username: string;
  name: string;
  email: string;
  role: "admin" | "staff";
  permissions: string[];
  isActive: boolean;
  createdAt: string;
  lastLogin?: string;
}

interface UserContextType {
  users: SystemUser[];
  addUser: (user: Omit<SystemUser, "id" | "createdAt"> & { password: string }) => Promise<void>;
  updateUser: (id: string, updates: Partial<SystemUser> & { password?: string }) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  getUser: (id: string) => SystemUser | undefined;
  getActiveUsers: () => SystemUser[];
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [users, setUsers] = useState<SystemUser[]>([]);

  useEffect(() => {
    api.get<SystemUser[]>('/users').then(setUsers).catch(console.error);
  }, []);

  const addUser = async (userData: Omit<SystemUser, "id" | "createdAt"> & { password: string }) => {
    const newUser = await api.post<SystemUser>('/users', userData);
    setUsers((prev) => [...prev, newUser]);
  };

  const updateUser = async (id: string, updates: Partial<SystemUser> & { password?: string }) => {
    const updated = await api.put<SystemUser>(`/users/${id}`, updates);
    setUsers((prev) => prev.map((u) => (u.id === id ? updated : u)));
  };

  const deleteUser = async (id: string) => {
    await api.delete(`/users/${id}`);
    setUsers((prev) => prev.filter((u) => u.id !== id));
  };

  const getUser = (id: string) => users.find((u) => u.id === id);

  const getActiveUsers = () => users.filter((u) => u.isActive);

  return (
    <UserContext.Provider
      value={{
        users,
        addUser,
        updateUser,
        deleteUser,
        getUser,
        getActiveUsers,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUserManagement = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUserManagement must be used within a UserProvider");
  }
  return context;
};
