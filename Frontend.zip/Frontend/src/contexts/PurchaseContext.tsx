import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../api/client';

export interface PurchaseItem {
  productId: string;
  productName: string;
  quantity: number;
  costPrice: number;
  total: number;
}

export interface Purchase {
  id: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseItem[];
  subtotal: number;
  tax: number;
  total: number;
  orderDate: string;
  expectedDelivery: string;
  status: 'pending' | 'delivered' | 'cancelled';
  invoiceNumber: string;
  createdAt: string;
  userId: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  createdAt: string;
}

interface PurchaseContextType {
  purchases: Purchase[];
  suppliers: Supplier[];
  addPurchase: (purchase: Omit<Purchase, 'id' | 'createdAt'>) => Promise<void>;
  updatePurchaseStatus: (id: string, status: Purchase['status']) => Promise<void>;
  addSupplier: (supplier: Omit<Supplier, 'id' | 'createdAt'>) => Promise<void>;
  updateSupplier: (id: string, updates: Partial<Supplier>) => Promise<void>;
  deleteSupplier: (id: string) => Promise<void>;
  getSupplier: (id: string) => Supplier | undefined;
  getPendingPurchases: () => Purchase[];
}

const PurchaseContext = createContext<PurchaseContextType | undefined>(undefined);

export const PurchaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  useEffect(() => {
    api.get<Purchase[]>('/purchases').then(setPurchases).catch(console.error);
    api.get<Supplier[]>('/suppliers').then(setSuppliers).catch(console.error);
  }, []);

  const addPurchase = async (purchaseData: Omit<Purchase, 'id' | 'createdAt'>) => {
    const newPurchase = await api.post<Purchase>('/purchases', purchaseData);
    setPurchases((prev) => [newPurchase, ...prev]);
  };

  const updatePurchaseStatus = async (id: string, status: Purchase['status']) => {
    const updated = await api.put<Purchase>(`/purchases/${id}`, { status });
    setPurchases((prev) => prev.map((p) => (p.id === id ? updated : p)));
  };

  const addSupplier = async (supplierData: Omit<Supplier, 'id' | 'createdAt'>) => {
    const newSupplier = await api.post<Supplier>('/suppliers', supplierData);
    setSuppliers((prev) => [newSupplier, ...prev]);
  };

  const updateSupplier = async (id: string, updates: Partial<Supplier>) => {
    const updated = await api.put<Supplier>(`/suppliers/${id}`, updates);
    setSuppliers((prev) => prev.map((s) => (s.id === id ? updated : s)));
  };

  const deleteSupplier = async (id: string) => {
    await api.delete(`/suppliers/${id}`);
    setSuppliers((prev) => prev.filter((s) => s.id !== id));
  };

  const getSupplier = (id: string) => suppliers.find((s) => s.id === id);

  const getPendingPurchases = () => purchases.filter((p) => p.status === 'pending');

  return (
    <PurchaseContext.Provider
      value={{
        purchases,
        suppliers,
        addPurchase,
        updatePurchaseStatus,
        addSupplier,
        updateSupplier,
        deleteSupplier,
        getSupplier,
        getPendingPurchases,
      }}
    >
      {children}
    </PurchaseContext.Provider>
  );
};

export const usePurchase = () => {
  const context = useContext(PurchaseContext);
  if (context === undefined) {
    throw new Error('usePurchase must be used within a PurchaseProvider');
  }
  return context;
};
